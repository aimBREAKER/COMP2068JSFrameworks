import React from 'react'

const Gap = ({ width, height }) => {
    return (
        <div style={{ width, height }} />
    )
}

export default Gap
