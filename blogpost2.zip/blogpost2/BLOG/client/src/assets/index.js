import RegisterBg from "./image/register-bg.jpg";
import LoginBg from "./image/login-bg.jpg";
import LogoMsn from "./image/editicon.jpg";
// icon
import ICFacebook from "./icon/facebook.svg";
import ICTwitter from "./icon/twitter.svg";
import ICInstagram from "./icon/instagram.svg";
import ICTelegram from "./icon/telegram.svg";
import ICDiscord from "./icon/discord.svg";
import ICGithub from "./icon/github.svg";

export {
  RegisterBg,
  LoginBg,
  LogoMsn,
  ICFacebook,
  ICTwitter,
  ICInstagram,
  ICTelegram,
  ICDiscord,
  ICGithub,
};
